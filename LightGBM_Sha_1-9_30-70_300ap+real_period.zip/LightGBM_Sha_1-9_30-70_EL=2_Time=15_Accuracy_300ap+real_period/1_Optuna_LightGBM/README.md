# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 1644
- **learning_rate**: 0.1
- **feature_fraction**: 0.359202807082142
- **bagging_fraction**: 0.8432828471157658
- **min_data_in_leaf**: 73
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 0.026629005564383426
- **lambda_l2**: 1.5607201197757081
- **bagging_freq**: 6
- **extra_trees**: True
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

50.6 seconds

## Metric details
|           |    score |     threshold |
|:----------|---------:|--------------:|
| logloss   | 0.227103 | nan           |
| auc       | 0.969085 | nan           |
| f1        | 0.924291 |   0.503871    |
| accuracy  | 0.920611 |   0.503871    |
| precision | 0.98423  |   0.960253    |
| recall    | 1        |   2.31228e-06 |
| mcc       | 0.842632 |   0.503871    |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.227103 |  nan        |
| auc       | 0.969085 |  nan        |
| f1        | 0.924291 |    0.503871 |
| accuracy  | 0.920611 |    0.503871 |
| precision | 0.897696 |    0.503871 |
| recall    | 0.952509 |    0.503871 |
| mcc       | 0.842632 |    0.503871 |


## Confusion matrix (at threshold=0.503871)
|              |   Predicted as 1 |   Predicted as 9 |
|:-------------|-----------------:|-----------------:|
| Labeled as 1 |             9221 |             1168 |
| Labeled as 9 |              511 |            10249 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
