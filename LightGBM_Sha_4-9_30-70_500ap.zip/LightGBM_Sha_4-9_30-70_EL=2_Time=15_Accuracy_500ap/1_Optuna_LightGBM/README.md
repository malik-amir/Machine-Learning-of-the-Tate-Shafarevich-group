# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 1451
- **learning_rate**: 0.025
- **feature_fraction**: 0.669044987828925
- **bagging_fraction**: 0.870640443623867
- **min_data_in_leaf**: 74
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 1.6331545480002496e-05
- **lambda_l2**: 0.00017081160660219948
- **bagging_freq**: 1
- **extra_trees**: False
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

167.6 seconds

## Metric details
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.602595 | nan         |
| auc       | 0.754328 | nan         |
| f1        | 0.727849 |   0.419582  |
| accuracy  | 0.694785 |   0.500319  |
| precision | 0.859748 |   0.74929   |
| recall    | 1        |   0.0840983 |
| mcc       | 0.389881 |   0.500319  |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.602595 |  nan        |
| auc       | 0.754328 |  nan        |
| f1        | 0.712049 |    0.500319 |
| accuracy  | 0.694785 |    0.500319 |
| precision | 0.684653 |    0.500319 |
| recall    | 0.741729 |    0.500319 |
| mcc       | 0.389881 |    0.500319 |


## Confusion matrix (at threshold=0.500319)
|              |   Predicted as 4 |   Predicted as 9 |
|:-------------|-----------------:|-----------------:|
| Labeled as 4 |             6713 |             3676 |
| Labeled as 9 |             2779 |             7981 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
