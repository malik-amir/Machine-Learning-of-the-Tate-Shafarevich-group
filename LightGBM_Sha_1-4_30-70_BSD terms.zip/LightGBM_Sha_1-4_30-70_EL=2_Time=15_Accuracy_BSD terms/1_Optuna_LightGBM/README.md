# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 967
- **learning_rate**: 0.1
- **feature_fraction**: 0.9374581314549255
- **bagging_fraction**: 0.30089620147999124
- **min_data_in_leaf**: 80
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 0.0014566769476278272
- **lambda_l2**: 0.001022998035570908
- **bagging_freq**: 7
- **extra_trees**: False
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

27.9 seconds

## Metric details
|           |    score |     threshold |
|:----------|---------:|--------------:|
| logloss   | 0.100427 | nan           |
| auc       | 0.993006 | nan           |
| f1        | 0.966438 |   0.499971    |
| accuracy  | 0.966601 |   0.499971    |
| precision | 1        |   0.99543     |
| recall    | 1        |   1.22424e-06 |
| mcc       | 0.933247 |   0.499971    |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.100427 |  nan        |
| auc       | 0.993006 |  nan        |
| f1        | 0.966438 |    0.499971 |
| accuracy  | 0.966601 |    0.499971 |
| precision | 0.971229 |    0.499971 |
| recall    | 0.961694 |    0.499971 |
| mcc       | 0.933247 |    0.499971 |


## Confusion matrix (at threshold=0.499971)
|              |   Predicted as 1 |   Predicted as 4 |
|:-------------|-----------------:|-----------------:|
| Labeled as 1 |            10093 |              296 |
| Labeled as 4 |              398 |             9992 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
