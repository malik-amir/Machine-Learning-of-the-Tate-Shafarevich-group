# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 1440
- **learning_rate**: 0.05
- **feature_fraction**: 0.9067783708525647
- **bagging_fraction**: 0.8821565213312483
- **min_data_in_leaf**: 96
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 8.522188610896275e-05
- **lambda_l2**: 0.000157431859753154
- **bagging_freq**: 3
- **extra_trees**: False
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

21.4 seconds

## Metric details
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.517949 |  nan        |
| auc       | 0.820395 |  nan        |
| f1        | 0.775872 |    0.399506 |
| accuracy  | 0.747742 |    0.497285 |
| precision | 0.927193 |    0.87297  |
| recall    | 1        |    0.005976 |
| mcc       | 0.501369 |    0.419003 |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.517949 |  nan        |
| auc       | 0.820395 |  nan        |
| f1        | 0.759522 |    0.497285 |
| accuracy  | 0.747742 |    0.497285 |
| precision | 0.737418 |    0.497285 |
| recall    | 0.782993 |    0.497285 |
| mcc       | 0.495756 |    0.497285 |


## Confusion matrix (at threshold=0.497285)
|              |   Predicted as 1 |   Predicted as 9 |
|:-------------|-----------------:|-----------------:|
| Labeled as 1 |             7389 |             3000 |
| Labeled as 9 |             2335 |             8425 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
