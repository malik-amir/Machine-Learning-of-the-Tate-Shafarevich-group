# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 595
- **learning_rate**: 0.1
- **feature_fraction**: 0.3691772743605295
- **bagging_fraction**: 0.5386858942859101
- **min_data_in_leaf**: 86
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 2.9724652223982717e-08
- **lambda_l2**: 7.206971614831588
- **bagging_freq**: 6
- **extra_trees**: True
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

62.5 seconds

## Metric details
|           |    score |    threshold |
|:----------|---------:|-------------:|
| logloss   | 0.478542 | nan          |
| auc       | 0.85288  | nan          |
| f1        | 0.791146 |   0.394985   |
| accuracy  | 0.771951 |   0.511131   |
| precision | 0.987288 |   0.940513   |
| recall    | 1        |   0.00122318 |
| mcc       | 0.544498 |   0.511131   |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.478542 |  nan        |
| auc       | 0.85288  |  nan        |
| f1        | 0.783187 |    0.511131 |
| accuracy  | 0.771951 |    0.511131 |
| precision | 0.758468 |    0.511131 |
| recall    | 0.809572 |    0.511131 |
| mcc       | 0.544498 |    0.511131 |


## Confusion matrix (at threshold=0.511131)
|              |   Predicted as 1 |   Predicted as 9 |
|:-------------|-----------------:|-----------------:|
| Labeled as 1 |             7615 |             2774 |
| Labeled as 9 |             2049 |             8711 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
