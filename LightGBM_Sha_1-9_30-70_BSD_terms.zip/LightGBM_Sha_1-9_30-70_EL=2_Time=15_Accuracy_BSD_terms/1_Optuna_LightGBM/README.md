# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 1975
- **learning_rate**: 0.1
- **feature_fraction**: 0.9435873867813886
- **bagging_fraction**: 0.35413032996827615
- **min_data_in_leaf**: 87
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 9.481784764225988e-08
- **lambda_l2**: 0.0008753833938167181
- **bagging_freq**: 6
- **extra_trees**: False
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

18.2 seconds

## Metric details
|           |     score |    threshold |
|:----------|----------:|-------------:|
| logloss   | 0.0364311 | nan          |
| auc       | 0.998868  | nan          |
| f1        | 0.98881   |   0.499916   |
| accuracy  | 0.988652  |   0.499916   |
| precision | 1         |   0.998293   |
| recall    | 1         |   4.2027e-08 |
| mcc       | 0.977322  |   0.499916   |


## Metric details with threshold from accuracy metric
|           |     score |   threshold |
|:----------|----------:|------------:|
| logloss   | 0.0364311 |  nan        |
| auc       | 0.998868  |  nan        |
| f1        | 0.98881   |    0.499916 |
| accuracy  | 0.988652  |    0.499916 |
| precision | 0.992141  |    0.499916 |
| recall    | 0.985502  |    0.499916 |
| mcc       | 0.977322  |    0.499916 |


## Confusion matrix (at threshold=0.499916)
|              |   Predicted as 1 |   Predicted as 9 |
|:-------------|-----------------:|-----------------:|
| Labeled as 1 |            10305 |               84 |
| Labeled as 9 |              156 |            10604 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
