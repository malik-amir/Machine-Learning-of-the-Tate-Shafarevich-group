# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 1598
- **learning_rate**: 0.1
- **feature_fraction**: 0.8613105322932351
- **bagging_fraction**: 0.970697557159987
- **min_data_in_leaf**: 36
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 2.840098794801191e-06
- **lambda_l2**: 3.0773599420974e-06
- **bagging_freq**: 7
- **extra_trees**: False
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

205.8 seconds

## Metric details
|           |    score |     threshold |
|:----------|---------:|--------------:|
| logloss   | 0.655872 | nan           |
| auc       | 0.749912 | nan           |
| f1        | 0.724204 |   0.238757    |
| accuracy  | 0.691664 |   0.495022    |
| precision | 0.834586 |   0.936161    |
| recall    | 1        |   4.06541e-05 |
| mcc       | 0.383045 |   0.495022    |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.655872 |  nan        |
| auc       | 0.749912 |  nan        |
| f1        | 0.703658 |    0.495022 |
| accuracy  | 0.691664 |    0.495022 |
| precision | 0.688484 |    0.495022 |
| recall    | 0.719517 |    0.495022 |
| mcc       | 0.383045 |    0.495022 |


## Confusion matrix (at threshold=0.495022)
|              |   Predicted as 4 |   Predicted as 9 |
|:-------------|-----------------:|-----------------:|
| Labeled as 4 |             6886 |             3503 |
| Labeled as 9 |             3018 |             7742 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
