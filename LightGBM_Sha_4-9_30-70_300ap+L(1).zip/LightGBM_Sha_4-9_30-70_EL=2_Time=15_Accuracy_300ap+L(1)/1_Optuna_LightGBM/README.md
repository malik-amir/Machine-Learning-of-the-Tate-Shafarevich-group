# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 1431
- **learning_rate**: 0.05
- **feature_fraction**: 0.8131545252357255
- **bagging_fraction**: 0.9806986301280055
- **min_data_in_leaf**: 45
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 2.2093901785357434e-06
- **lambda_l2**: 2.1085922394893846e-05
- **bagging_freq**: 5
- **extra_trees**: False
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

139.6 seconds

## Metric details
|           |    score |     threshold |
|:----------|---------:|--------------:|
| logloss   | 0.592414 | nan           |
| auc       | 0.743007 | nan           |
| f1        | 0.724065 |   0.349733    |
| accuracy  | 0.686084 |   0.499156    |
| precision | 0.857534 |   0.894404    |
| recall    | 1        |   0.000771329 |
| mcc       | 0.373558 |   0.499156    |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.592414 |  nan        |
| auc       | 0.743007 |  nan        |
| f1        | 0.709415 |    0.499156 |
| accuracy  | 0.686084 |    0.499156 |
| precision | 0.670472 |    0.499156 |
| recall    | 0.75316  |    0.499156 |
| mcc       | 0.373558 |    0.499156 |


## Confusion matrix (at threshold=0.499156)
|              |   Predicted as 4 |   Predicted as 9 |
|:-------------|-----------------:|-----------------:|
| Labeled as 4 |             6406 |             3983 |
| Labeled as 9 |             2656 |             8104 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
