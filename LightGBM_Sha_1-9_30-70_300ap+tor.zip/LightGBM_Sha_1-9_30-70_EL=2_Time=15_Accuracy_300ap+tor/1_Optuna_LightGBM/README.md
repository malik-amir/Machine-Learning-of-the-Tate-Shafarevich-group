# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 937
- **learning_rate**: 0.1
- **feature_fraction**: 0.7653569679658672
- **bagging_fraction**: 0.7876277176386991
- **min_data_in_leaf**: 85
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 0.000345999000475321
- **lambda_l2**: 2.068724922383807
- **bagging_freq**: 2
- **extra_trees**: True
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

62.7 seconds

## Metric details
|           |    score |     threshold |
|:----------|---------:|--------------:|
| logloss   | 0.481084 | nan           |
| auc       | 0.850014 | nan           |
| f1        | 0.790005 |   0.392706    |
| accuracy  | 0.772802 |   0.495336    |
| precision | 0.973684 |   0.967509    |
| recall    | 1        |   0.000227913 |
| mcc       | 0.546863 |   0.495336    |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.481084 |  nan        |
| auc       | 0.850014 |  nan        |
| f1        | 0.785902 |    0.495336 |
| accuracy  | 0.772802 |    0.495336 |
| precision | 0.754857 |    0.495336 |
| recall    | 0.81961  |    0.495336 |
| mcc       | 0.546863 |    0.495336 |


## Confusion matrix (at threshold=0.495336)
|              |   Predicted as 1 |   Predicted as 9 |
|:-------------|-----------------:|-----------------:|
| Labeled as 1 |             7525 |             2864 |
| Labeled as 9 |             1941 |             8819 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
