# AutoML Leaderboard

| Best model   | name                                             | model_type   | metric_type   |   metric_value |   train_time |
|:-------------|:-------------------------------------------------|:-------------|:--------------|---------------:|-------------:|
| **the best** | [1_Optuna_LightGBM](1_Optuna_LightGBM/README.md) | LightGBM     | accuracy      |       0.988699 |        25.94 |