# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 1357
- **learning_rate**: 0.1
- **feature_fraction**: 0.9695708726440534
- **bagging_fraction**: 0.4440345901659299
- **min_data_in_leaf**: 76
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 3.302138335400748e-07
- **lambda_l2**: 5.710269767967543e-06
- **bagging_freq**: 4
- **extra_trees**: False
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

24.9 seconds

## Metric details
|           |     score |     threshold |
|:----------|----------:|--------------:|
| logloss   | 0.0434895 | nan           |
| auc       | 0.99849   | nan           |
| f1        | 0.988905  |   0.500428    |
| accuracy  | 0.988747  |   0.500428    |
| precision | 1         |   0.999992    |
| recall    | 1         |   1.33924e-07 |
| mcc       | 0.977509  |   0.500428    |


## Metric details with threshold from accuracy metric
|           |     score |   threshold |
|:----------|----------:|------------:|
| logloss   | 0.0434895 |  nan        |
| auc       | 0.99849   |  nan        |
| f1        | 0.988905  |    0.500428 |
| accuracy  | 0.988747  |    0.500428 |
| precision | 0.99205   |    0.500428 |
| recall    | 0.985781  |    0.500428 |
| mcc       | 0.977509  |    0.500428 |


## Confusion matrix (at threshold=0.500428)
|              |   Predicted as 4 |   Predicted as 9 |
|:-------------|-----------------:|-----------------:|
| Labeled as 4 |            10304 |               85 |
| Labeled as 9 |              153 |            10607 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
