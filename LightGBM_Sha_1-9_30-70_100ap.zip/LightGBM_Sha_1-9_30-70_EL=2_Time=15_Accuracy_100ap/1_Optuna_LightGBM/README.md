# Summary of 1_Optuna_LightGBM

[<< Go back](../README.md)


## LightGBM
- **n_jobs**: -1
- **objective**: binary
- **num_leaves**: 1970
- **learning_rate**: 0.05
- **feature_fraction**: 0.3111012957999674
- **bagging_fraction**: 0.7187619349191975
- **min_data_in_leaf**: 1
- **metric**: custom
- **custom_eval_metric_name**: accuracy
- **lambda_l1**: 6.011589603351301
- **lambda_l2**: 0.05543929251512283
- **bagging_freq**: 7
- **extra_trees**: False
- **num_boost_round**: 1000
- **early_stopping_rounds**: 50
- **cat_feature**: []
- **feature_pre_filter**: False
- **explain_level**: 0

## Validation
 - **validation_type**: kfold
 - **k_folds**: 10
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
accuracy

## Training time

83.9 seconds

## Metric details
|           |    score |    threshold |
|:----------|---------:|-------------:|
| logloss   | 0.514576 | nan          |
| auc       | 0.829885 | nan          |
| f1        | 0.781355 |   0.408316   |
| accuracy  | 0.756963 |   0.494783   |
| precision | 0.930147 |   0.884219   |
| recall    | 1        |   0.00257539 |
| mcc       | 0.515027 |   0.494783   |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.514576 |  nan        |
| auc       | 0.829885 |  nan        |
| f1        | 0.771047 |    0.494783 |
| accuracy  | 0.756963 |    0.494783 |
| precision | 0.740376 |    0.494783 |
| recall    | 0.804368 |    0.494783 |
| mcc       | 0.515027 |    0.494783 |


## Confusion matrix (at threshold=0.494783)
|              |   Predicted as 1 |   Predicted as 9 |
|:-------------|-----------------:|-----------------:|
| Labeled as 1 |             7354 |             3035 |
| Labeled as 9 |             2105 |             8655 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
