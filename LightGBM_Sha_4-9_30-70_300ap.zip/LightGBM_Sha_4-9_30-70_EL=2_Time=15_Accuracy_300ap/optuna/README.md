# Optuna tuning for LightGBM on original data

## LightGBM Optimization History

![LightGBM original optimization_history](original_LightGBM_optimization_history.png)

## LightGBM Parallel Coordinate

![LightGBM original parallel_coordinate](original_LightGBM_parallel_coordinate.png)

## LightGBM Param Importances

![LightGBM original param_importances](original_LightGBM_param_importances.png)



[<< Go back](../README.md)
